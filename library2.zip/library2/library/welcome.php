<?php
session_start();
include_once('connection.php');

// if(isset($_SESSION['name']) && isset($_SESSION['username'] )){

// }
$_SESSION['name'];
$_SESSION['username'];
?>
<?php
session_start();
include_once('connection.php');

// if(isset($_SESSION['name']) && isset($_SESSION['username'] )){

// }
$_SESSION['name'];
$_SESSION['username'];
?>
<?php
session_start();
include_once('connection.php');

// if(isset($_SESSION['name']) && isset($_SESSION['username'] )){

// }
$_SESSION['name'];
$_SESSION['username'];
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Book Store Website</title>
    <link rel="stylesheet" href="style.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.1.1/css/all.min.css" integrity="sha512-KfkfwYDsLkIlwQp6LFnl8zNdLGxu9YAA1QvwINks4PhcElQSvqcyVLLD9aMhXd13uQjoXtEKNosOWaZqXgel0g==" crossorigin="anonymous" referrerpolicy="no-referrer" />
</head>
<body>
    
    <section>

        <nav>

            <div class="logo">
                <img src="image/logo.png">
            </div>

            <ul>
                <li><a href="Home.php">Home</a></li>
                <li><a href="Books.php">Books</a></li>
                <li><a href="contuct.php">Contact Us</a></li>
                <li><a href="about.php">About us</a></li>
                
                
            </ul>

            <div class="social_icon">
                <i class="fa-solid fa-magnifying-glass"></i>
                
            </div>

        </nav>

        <div class="main">

            <div class="main_tag">
                <h1>WELCOME TO OUR-LIBRARY<br><span>BOOK STORE</span></h1>

                <p>
                    Explore the world of knowledge and discovery at your fingertips. Our library is dedicated to providing a welcoming and inclusive environment for all, where you can access a vast array of books, media, and online resources. Whether you're a student, researcher, or simply a curious mind, we invite you to browse our collections, attend our events, and connect with our community. Let us help you unlock the power of knowledge and imagination!"
                </p>
                

            </div>

            <div class="main_img">
                <img src="image/table.png">
            </div>

        </div>

    </section>

<link
      href="https://fonts.googleapis.com/css2?family=Poppins:ital,wght@0,100;0,200;0,300;0,400;0,500;0,600;0,700;0,800;0,900;1,100;1,200;1,300;1,400;1,500;1,600;1,700;1,800;1,900&display=swap"
      rel="stylesheet"
    />
    
    <link rel="stylesheet" href="style.css" />
  </head>
  <body>
    
  
    <div class="slider-container">
      <div class="slider">
        <!-- Slide 1 -->

        <div class="slide">
          <img src="image/img11.jpg" alt="Slide 1" />
          <div class="slide-content">
            <h1>WELCOME TO OUR-LIBRARY</h1>
            <h2>This Weekend Books</h2>
            <br />
            <p>
              Lorem ipsum dolor sit, amet consectetur adipisicing elit. Officiis
              a culpa, nobis quaerat alias hic tempore expedita <br />
              voluptates debitis, tenetur doloribus enim rerum, voluptas
              molestiae nemo vero? Alias, dolores nam.
            </p>
          </div>
        </div>
        <!-- Slide 2 -->

        <div class="slide">
          <img src="image/img2.jpg" alt="Slide 2" />
          <div class="slide-content">
             <h1>WELCOME TO OUR-LIBRARY</h1>
            <h2>This Weekend Books</h2>
            <br />
            <p>
              Lorem ipsum dolor sit, amet consectetur adipisicing elit. Officiis
              a culpa, nobis quaerat alias hic tempore expedita <br />
              voluptates debitis, tenetur doloribus enim rerum, voluptas
              molestiae nemo vero? Alias, dolores nam.
            </p>
          </div>
        </div>
        <!-- Slide 3 -->

        <div class="slide">
          <img src="image/img3.jpg" alt="Slide 3" />
          <div class="slide-content">
            < <h1>WELCOME TO OUR-LIBRARY</h1>
            <h2>This Weekend Books</h2>
            <br />
            <p>
              Lorem ipsum dolor sit, amet consectetur adipisicing elit. Officiis
              a culpa, nobis quaerat alias hic tempore expedita <br />
              voluptates debitis, tenetur doloribus enim rerum, voluptas
              molestiae nemo vero? Alias, dolores nam.
            </p>
          </div>
        </div>
        <!-- Slide 4 -->

        <div class="slide">
          <img src="image/img4.jpg" alt="Slide 4" />
          <div class="slide-content">
            <h1>Welcome! Selam</h1>
            <h2>BigMak Ethiopian Restaurant</h2>
            <br />
            <p>
              Lorem ipsum dolor sit, amet consectetur adipisicing elit. Officiis
              a culpa, nobis quaerat alias hic tempore expedita <br />
              voluptates debitis, tenetur doloribus enim rerum, voluptas
              molestiae nemo vero? Alias, dolores nam.
            </p>
          </div>
        </div>
        <!-- Slide 5 -->

        <div class="slide">
          <img src="image/img5.jpg" alt="Slide 5" />
          <div class="slide-content">
            <h1>Welcome! Selam</h1>
            <h2>BigMak Ethiopian Restaurant</h2>
            <br />
            <p>
              Lorem ipsum dolor sit, amet consectetur adipisicing elit. Officiis
              a culpa, nobis quaerat alias hic tempore expedita <br />
              voluptates debitis, tenetur doloribus enim rerum, voluptas
              molestiae nemo vero? Alias, dolores nam.
            </p>
          </div>
        </div>
      </div>
      <!-- Navigation buttons -->

      <button class="prev" onclick="prevSlide()">&lt</button>
      <button class="next" onclick="nextSlide()">&gt</button>

    <script src="sstyle.js"></script>
  </body>
</html>



    <!--Services-->

    <div class="services">

        <div class="services_box">

            <div class="services_card">
               
                
                
            </div>

            <div class="services_card">
                <h3>24 x 7 Services</h3>
                <p>
                    twenty-four seven
                </p>
            </div>

            <div class="services_card">
                
                <h3>Best site</h3>
                <p>
                    The Library is free for thinkers.
                </p>
     </div>

            <div class="services_card">
                
                </p>
            </div>

        </div>

    </div>
    <title>Login Page</title>
  
</head>
<body>
    

    <footer>
        <div class="footer_main">

            <div class="tag">
                <img src="image/logo.png">
                <p>
                    "Discover the Power of Knowledge Here!"
                </p>

            </div>

            <div class="tag">
                <h1>Quick Link</h1>
                <li><a href="Home.php">Home</a></li>
                <li><a href="Books.php">Books</a></li>
                <li><a href="contuct.php">Contact Us</a></li>
                <li><a href="about.php">About us</a></li>
                
                
            </div>

            <div class="tag">
                <h1>Contact Info</h1>
                <a href="#"><i class="fa-solid fa-phone"></i>+251900000000</a>
                <a href="#"><i class="fa-solid fa-phone"></i>+251900000000</a>
                <a href="#"><i class="fa-solid fa-envelope"></i>samifmskyf@gmail.com</a>
                
            </div>

            <div class="tag">
                <h1>Follow Us</h1>
                <div class="social_link">
                    <i class="fa-brands fa-facebook-f"></i>
                    <i class="fa-brands fa-instagram"></i>
                    <i class="fa-brands fa-twitter"></i>
                    <i class="fa-brands fa-linkedin-in"></i>
                </div>
                
            </div>

            <div class="tag">
                <h1>Newsletter</h1>
                <div class="search_bar">
                    <input type="text" placeholder="You email id here">
                    <button type="submit">Subscribe</button>
                </div>                
            </div>            
            
        </div>

        <p class="end">Design By<span><i class="fa-solid fa-face-grin"></i> AAiT Software Engineer Students</span></p>

    </footer>





    
</body>
</html>
</html>